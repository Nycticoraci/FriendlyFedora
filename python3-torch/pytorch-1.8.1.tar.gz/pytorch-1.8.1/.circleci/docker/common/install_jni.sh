#!/bin/bash

set -ex

mkdir -p /usr/local/include
cp jni.h /usr/local/include

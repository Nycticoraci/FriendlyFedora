#include <ATen/TensorMeta.h>

namespace at {

} // namespace at
